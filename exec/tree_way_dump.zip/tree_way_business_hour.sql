-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: tree_way
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `business_hour`
--

DROP TABLE IF EXISTS `business_hour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_hour` (
  `business_id` bigint NOT NULL AUTO_INCREMENT,
  `business_time` int DEFAULT NULL,
  `industry_detail_id` bigint DEFAULT NULL,
  PRIMARY KEY (`business_id`),
  KEY `FKdrne6miekfb9n1gdhyxo7qu8o` (`industry_detail_id`),
  CONSTRAINT `FKdrne6miekfb9n1gdhyxo7qu8o` FOREIGN KEY (`industry_detail_id`) REFERENCES `industry_detail` (`industry_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_hour`
--

LOCK TABLES `business_hour` WRITE;
/*!40000 ALTER TABLE `business_hour` DISABLE KEYS */;
INSERT INTO `business_hour` VALUES (1,0,10),(2,1,11),(3,1,12),(4,1,13),(5,1,14),(6,1,15),(7,1,16),(8,1,17),(9,1,18),(10,1,19),(11,1,110),(12,1,111),(13,2,11),(14,2,12),(15,2,13),(16,2,14),(17,2,16),(18,2,17),(19,2,18),(20,2,19),(21,2,110),(22,2,111),(23,3,11),(24,3,12),(25,3,13),(26,3,14),(27,3,16),(28,3,17),(29,3,18),(30,3,19),(31,3,110),(32,3,111),(33,0,100),(34,1,112),(35,1,113),(36,1,114),(37,1,115),(38,1,116),(39,1,117),(40,1,118),(41,2,114),(42,2,116),(43,2,118),(44,3,114),(45,3,116),(46,3,118),(47,0,40),(48,1,41),(49,1,42),(50,1,43),(51,1,44),(52,1,45),(53,1,46),(54,1,47),(55,1,48),(56,1,49),(57,1,410),(58,1,411),(59,1,412),(60,1,413),(61,1,414),(62,1,415),(63,2,41),(64,3,41),(65,0,20),(66,1,21),(67,1,22),(68,1,23),(69,1,24),(70,1,25),(71,1,26),(72,1,27),(73,1,28),(74,1,29),(75,1,210),(76,1,211),(77,1,212),(78,1,213),(79,1,214),(80,1,215),(81,1,216),(82,1,217),(83,2,21),(84,2,22),(85,2,23),(86,2,24),(87,2,26),(88,2,27),(89,2,28),(90,2,29),(91,2,210),(92,2,211),(93,2,212),(94,2,213),(95,2,214),(96,2,215),(97,2,216),(98,2,217),(99,3,21),(100,3,22),(101,3,23),(102,3,211),(103,3,215),(104,3,216),(105,3,217),(106,0,30),(107,1,31),(108,1,32),(109,1,33),(110,1,34),(111,1,35),(112,2,32),(113,0,1000),(114,1,119),(115,1,120),(116,1,121),(117,1,122),(118,2,119),(119,2,120),(120,2,121),(121,2,122),(122,3,119),(123,3,120),(124,3,121),(125,3,122),(126,1,1);
/*!40000 ALTER TABLE `business_hour` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  9:07:08
