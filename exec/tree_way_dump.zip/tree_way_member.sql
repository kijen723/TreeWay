-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: tree_way
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `member_id` bigint NOT NULL AUTO_INCREMENT,
  `age` int DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `member_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `profile_img` bigint DEFAULT NULL,
  `is_deleted` bit(1) DEFAULT NULL,
  `registered_time` datetime(6) DEFAULT NULL,
  `oauth_email` varchar(255) DEFAULT NULL,
  `oauth_id` varchar(100) DEFAULT NULL,
  `oauth_provider` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (4,0,'dawoon221@gmail.com','창업왕','[대전_3반_정다운]','1111','ROLE_USER',32,NULL,NULL,NULL,NULL,NULL),(12,0,'email3738718881','김인제','김인제','123','ROLE_USER',NULL,_binary '\0','2024-10-09 22:52:01.449345',NULL,NULL,NULL),(13,NULL,'kij2646@gmail.com','김인제','김인제',NULL,'ROLE_USER',NULL,_binary '\0','2024-10-09 22:54:59.800967',NULL,NULL,NULL),(27,0,'email3738335593','강지우','강지우','1234','ROLE_USER',30,_binary '\0','2024-10-09 23:39:33.021694',NULL,NULL,NULL),(28,0,'email3739873639','정다운','정다운','0000','ROLE_USER',26,_binary '\0','2024-10-09 23:51:10.650053',NULL,NULL,NULL),(29,28,'email3740653999','김연동','김연동','01028232415','ROLE_USER',28,_binary '\0','2024-10-09 23:53:24.307737',NULL,NULL,NULL),(32,0,'rkdwldn789@gmail.com','강지우','강지우','1234','ROLE_USER',NULL,_binary '\0','2024-10-10 00:30:25.903998',NULL,NULL,NULL),(33,0,'email3741181598','박민호','박민호','01032895508','ROLE_USER',27,_binary '\0','2024-10-10 10:32:51.347718',NULL,NULL,NULL),(34,NULL,'dusehd0525@gmail.com','김연동','김연동',NULL,'ROLE_USER',NULL,_binary '\0','2024-10-10 10:35:14.388333',NULL,NULL,NULL),(35,25,'email3741462047','전성모','전성모','01079394420','ROLE_USER',31,_binary '\0','2024-10-10 12:58:37.876231',NULL,NULL,NULL),(36,29,'dawoon221@sookmyung.ac.kr','신형만','신형만','01012345678','ROLE_USER',NULL,_binary '\0','2024-10-11 02:02:49.559381',NULL,NULL,NULL);
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  9:07:14
