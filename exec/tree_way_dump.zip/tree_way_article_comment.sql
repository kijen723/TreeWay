-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: tree_way
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article_comment`
--

DROP TABLE IF EXISTS `article_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article_comment` (
  `article_comment_id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(3000) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `article_id` bigint NOT NULL,
  `member_id` bigint NOT NULL,
  PRIMARY KEY (`article_comment_id`),
  KEY `FKk9vyararhec6o9v70qg1pjmo3` (`member_id`),
  KEY `FKghmocqkgqs5tkmucf5putw64t` (`article_id`),
  CONSTRAINT `FKghmocqkgqs5tkmucf5putw64t` FOREIGN KEY (`article_id`) REFERENCES `article` (`article_id`) ON DELETE CASCADE,
  CONSTRAINT `FKk9vyararhec6o9v70qg1pjmo3` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_comment`
--

LOCK TABLES `article_comment` WRITE;
/*!40000 ALTER TABLE `article_comment` DISABLE KEYS */;
INSERT INTO `article_comment` VALUES (11,'와 정말 좋은정보네요\n꿀팁 감사합니다!','2024-10-11 01:50:40.000000',45,28),(12,'회가 정말 맛있겠어요~','2024-10-11 01:55:33.000000',39,4),(13,'편의점 창업도 신경쓸게 많네요. 좋은 정보 감사합니다','2024-10-11 02:04:46.000000',49,36),(15,'회 포장 전문점, 좋은 아이템 선택하셨네요. 중요한 건 신선도 유지와 포장 기술이라고 생각합니다. 잘 준비하셔서 성공하시길 바랍니다!','2024-10-11 02:11:34.000000',50,4),(17,'직장인이 많은 역세권이나 오피스 밀집 지역을 추천드리며, 20~30대 젊은 층을 타겟으로 하신다면 가로수길이나 압구정 로데오도 좋은 선택입니다. ','2024-10-11 02:13:37.000000',48,4),(18,'완전 좋은 아이디어인데요? 저도 퇴근하고 회 포장해 가고 싶어요!','2024-10-11 02:41:17.000000',50,28),(19,'꿀팁이네요 따봉 드립니다','2024-10-11 02:41:40.000000',49,28);
/*!40000 ALTER TABLE `article_comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  9:07:06
