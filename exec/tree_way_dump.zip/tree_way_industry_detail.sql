-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: tree_way
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `industry_detail`
--

DROP TABLE IF EXISTS `industry_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `industry_detail` (
  `industry_detail_id` bigint NOT NULL,
  `industry_detail_name` varchar(255) NOT NULL,
  `industry_id` bigint NOT NULL,
  PRIMARY KEY (`industry_detail_id`),
  KEY `FK1x4kqbhcrfsne1pif882lyjfx` (`industry_id`),
  CONSTRAINT `FK1x4kqbhcrfsne1pif882lyjfx` FOREIGN KEY (`industry_id`) REFERENCES `industry` (`industry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `industry_detail`
--

LOCK TABLES `industry_detail` WRITE;
/*!40000 ALTER TABLE `industry_detail` DISABLE KEYS */;
INSERT INTO `industry_detail` VALUES (1,'기타',5),(2,'예술/스포츠/시설업',2),(3,'교육/학원업',3),(4,'도/소매업',4),(5,'외식업',1),(10,'전체',1),(11,'한식	',1),(12,'중식',1),(13,'회',1),(14,'양식',1),(15,'분식',1),(16,'육류',1),(17,'주류',1),(18,'버거류',1),(19,'커피',1),(20,'전체',2),(21,'노래방',2),(22,'당구장',2),(23,'독서실',2),(24,'헬스클럽',2),(25,'바둑기원',2),(26,'볼링장',2),(27,'무도장',2),(28,'음악작업',2),(29,'탁구장',2),(30,'전체',3),(31,'어린이집',3),(32,'학원',3),(33,'키즈카페',3),(34,'미술업',3),(35,'공방',3),(40,'전체',4),(41,'편의점',4),(42,'슈퍼마켓',4),(43,'청과류',4),(44,'정육점',4),(45,'의류가방',4),(46,'약국',4),(47,'문구류',4),(48,'액세서리',4),(49,'화장품',4),(100,'전체',1),(110,'배달전문',1),(111,'유흥주점',1),(112,'미용실',1),(113,'뷰티',1),(114,'마사지',1),(115,'세탁소',1),(116,'사우나',1),(117,'카센터',1),(118,'호텔',1),(119,'호텔모텔',1),(120,'숙박업',1),(121,'캠핑장',1),(122,'원룸텔',1),(210,'실내골프',2),(211,'실내야구',2),(212,'축구',2),(213,'실내낚시',2),(214,'스포츠',2),(215,'무인사진',2),(216,'코인노래방',2),(217,'코인빨래방',2),(410,'리빙가구',4),(411,'귀금속',4),(412,'가전제품',4),(413,'자재',4),(414,'식물',4),(415,'애견용품',4),(1000,'전체',1);
/*!40000 ALTER TABLE `industry_detail` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  9:07:49
