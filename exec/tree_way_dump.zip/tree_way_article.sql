-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: tree_way
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article` (
  `article_id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(3000) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `title` varchar(255) NOT NULL,
  `view_count` int NOT NULL DEFAULT '0',
  `industry_detail_id` bigint NOT NULL,
  `member_id` bigint NOT NULL,
  `region_id` bigint NOT NULL,
  `is_deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`article_id`),
  KEY `FKnhl7qs2y764qai6a2n70a5ul6` (`industry_detail_id`),
  KEY `FK6l9vkfd5ixw8o8kph5rj1k7gu` (`member_id`),
  KEY `FKncah7n8ik3b5oewpr72mo4cfy` (`region_id`),
  CONSTRAINT `FK6l9vkfd5ixw8o8kph5rj1k7gu` FOREIGN KEY (`member_id`) REFERENCES `member` (`member_id`),
  CONSTRAINT `FKncah7n8ik3b5oewpr72mo4cfy` FOREIGN KEY (`region_id`) REFERENCES `region` (`region_id`),
  CONSTRAINT `FKnhl7qs2y764qai6a2n70a5ul6` FOREIGN KEY (`industry_detail_id`) REFERENCES `industry_detail` (`industry_detail_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (39,'<p><span style=\"color: rgb(34, 34, 34);\">세계 일류 상품이자 제주를 대표하는 청정수산물인 제주광어를 테마로 한 \'2024 제7회 제주광어대축제\'가 성황리에 마무리됐다.</span></p><p><br></p><p><span style=\"color: rgb(34, 34, 34);\">제주어류양식수협(한용선 조합장)이 주최하고 제주특별자치도와 수협중앙회가 후원하는 제주광어 대축제는 지난 5일과 6일 이틀간 제주어류양식수협 본소(연삼로 166)에서 열렸다.</span></p><p><br></p><p><span style=\"color: rgb(34, 34, 34);\">이 축제는 \'제주바다가 키운 제주광어, 청정에 안심을 더하다\'라는 슬로건으로 국민횟감인 제주 광어의 우수성을 알리고 소비를 진작시키기 위해 마련됐다.</span></p><p><br></p><p><span style=\"color: rgb(34, 34, 34);\">출처 : 헤드라인제주(http://www.headlinejeju.co.kr)</span><img src=\"[image0]\"></p>','2024-10-10 13:25:35','2024-10-10 17:32:52','회 축제',5,13,27,50,0),(42,'<p><span style=\"color: rgb(18, 18, 18);\">삼시 세끼를 해결하는 것만으로 행복하던 때가 있었다. 밥 한 그릇에 찬기 하나만 있어도 둘러앉은 식구(食口)가 있기에 넉넉하고 풍성한 식탁이었다. 시간은 흐르고 흘러 이제는 또 다른 의미에서 제대로 한 끼를 채우기 어려운 시대가 됐다. 바쁜 일상 속 빠르고 간편한 식문화는 ‘감동’을 앗아갔고 엄마의 ‘손맛’이 그리워지게 했다. 값비싼 코스 요리를 뒤로하고 ‘집밥’이 뜨는 배경이다. 그리고 시장은 정확히 트렌드를 읽어 냈다. 지금은 바야흐로 한식의 전성시대다.</span><img src=\"[image0]\"></p>','2024-10-10 13:27:26','2024-10-10 16:51:06','집밥이 최고야',3,11,27,11,0),(43,'<p><span style=\"color: rgb(18, 18, 18);\">가요계의 리메이크 열풍으로 원곡이 재조명되는 현상이 노래방 업계에서도 나타나고 있다.</span></p><p><br></p><p><span style=\"color: rgb(18, 18, 18);\">국내 노래방 업계 1위 TJ미디어(티제이미디어)는 비투비 멤버 이창섭의 ‘천상연’이 6개월간 노래방 인기차트 1위(2024년 9월 기준)를 차지했다고 밝혔다. 이창섭의 ‘천상연’은 남성 듀오 ‘캔’이 1998년 발매한 곡을 리메이크한 것으로, 발매 이후 꾸준히 노래방 인기차트 상위권을 유지하고 있다.</span></p><p><br></p><p><span style=\"color: rgb(18, 18, 18);\">노래방 가야겠어요~</span><img src=\"[image0]\"></p>','2024-10-10 13:28:42','2024-10-10 16:50:54','노래방이 유행이라네요~',3,21,27,11,0),(44,'<p>송고시간2024-07-30 16:38&nbsp;<strong>요약</strong></p><p>기자</p><p class=\"ql-align-center\"><img src=\"[image0]\"></p><p class=\"ql-align-center\"><br></p><p>원광대학교 전경</p><p>[원광대 제공]</p><p>(익산=연합뉴스) 정경재 기자 = 전북 익산에 있는 원광대학교 교정에 시민 누구나 즐길 수 있는 체육시설이 들어선다.</p><p>정헌율 익산시장과 박성태 원광대 총장은 30일 시청에서 이러한 내용을 담은 \'시민개방형 체육시설 조성사업\' 업무협약을 체결했다.</p><p>익산시는 전북특별자치도 공모 선정으로 확보한 도비 등 약 35억원을 들여 이르면 연내 원광대 내 약 2만5천㎡ 부지에 야구장, 테니스장, 풋살장, 족구장을 조성할 계획이다.</p><p><br></p>','2024-10-10 13:31:43','2024-10-10 16:50:49','풋살장 차리실분~',2,212,27,52,0),(45,'<p>성북구에서 사업을 운영하면서 꿀팁을 드리자면, 먼저 이 지역은 대학생과 직장인들이 많아서 상권 분석이 중요해요. 고려대나 한성대 주변은 특히 대학생들이 많이 다니는 곳이라, 할인 행사나 이벤트를 진행하면 좋은 반응을 얻을 수 있을 거예요.</p><p><br></p><p>요즘엔 온라인과 오프라인을 연계한 마케팅이 대세이니까, 온라인 쇼핑몰과 오프라인 매장을 잘 연결해주는 프로모션도 고려해보세요.</p><p><br></p><p>그리고 성북구에는 다양한 소상공인 지원 프로그램이 있어서 이를 적극적으로 활용하는 것도 생각해보시면 정말 좋을거에요. 저도 이걸로 득 많이 봤어요ㅋㅋ.</p><p>창업지원센터나 구청에서 제공하는 자금을 이용해 사업을 확장하시는것도 추천!!</p><p><br></p><p>또 친환경 제품이나 재활용 관련 제품을 취급하는 것도 요즘 소비자들의 관심을 끌 수 있어요. 그런걸로 사람 모으는거로도 잘 되더라구요??</p><p><br></p><p>SNS를 적극적으로 활용하는 것도 추천해요. 인스타그램이나 페이스북 같은 소셜미디어에서 성북구와 관련된 해시태그를 활용하면 많은 사람들에게 노출될 수 있고, 이 지역에서 내 상점을 알리는 데 큰 도움이 될 거예요. 다들 번창하세유!!</p>','2024-10-10 14:26:21','2024-10-10 17:32:59','성북구에 계시는 사장님들께 꿀팁~!',8,13,33,11,0),(46,'<p>오늘 횟집에서 손님과 좀 시끄럽게 다퉜네요 진짜 참을라고했는데 순간적으로 욱해서 욕이 나가버렸어요. </p><p>손님이 정말 많은 한가운데서 손님이 다짜고짜 욕하시길레 나가라고 욕했는데, 진짜 내가 잘못한 건지 헷갈려서요. </p><p><br></p><p>손님이 다짜고짜 욕을하시니까 결국 좀 큰 소리로 싸우게 됐어요. 제가 너무 짜증을 낸 걸까요? </p><p>그때 그냥 분위기를 가라앉혀드리고 식사 마저 하고 나가라고 하는게 맞았을까요?</p><p><br></p><p>제가 과민반응을 한건지, 아니면 손님이 지나치게 행동한 건지, 여러분 생각은 어떠세요? 경험이 있으신 분들께 조언도 듣고 싶습니다. 이런 상황에서 어떻게 대처하는 게 좋을지 알려주세요..</p>','2024-10-10 14:30:47','2024-10-10 17:14:32','사장님들 이런건 어떻게 생각하세요?',4,13,33,11,0),(47,'<p>오늘 하루는 진짜 장사가 너무 안 됐네요;;;</p><p><br></p><p> 아침부터 손님이 한 명도 없고, 오후가 되니까 조금 기대했는데도 여전히 썰렁해서 마음이 많이 무겁네요. </p><p>이런 날도 있는 거지만, 가게 문을 열고 이렇게 하루 종일 허탕 치면 정말 기운 빠지고, 많이 속상해요.</p><p><br></p><p>특히 요즘 물가도 오르고 재료값도 계속 올라서 장사하기가 더 힘든 것 같아요. 손님들이 적다 보니 매출도 떨어지고, </p><p>이럴 때마다 더 열심히 해야겠다는 마음과 함께 언제쯤 상황이 나아질까하는 불안한 마음이 교차하네요.</p><p>그래도 저는 언제나 믿고 찾아주는 단골손님들 덕분에 버티고 있는 거겠죠. </p><p>오늘처럼 힘든 날에도 그분들이 많이 생각나요. 다들 요즘 장사는 어떠신가요? 저만 이런 건지 궁금하네요. 다들 힘내시고, 좋은 하루 되세요!</p>','2024-10-10 14:32:34','2024-10-10 20:14:42','오늘 너무 속상하네요',13,13,33,11,0),(48,'<p><img src=\"[image0]\" width=\"272\" style=\"cursor: nesw-resize;\"></p><p>안녕하세요! 저는 카페 창업을 준비 중인 예비 창업자입니다. </p><p>현재 서울 강남구를 창업 지역으로 생각하고 있는데요, 여러 가지 고려해야 할 사항들이 많아 고민이 깊습니다. </p><p><br></p><p>강남구는 유동 인구가 많고 상권도 좋은 곳이 많다고 하지만, 동시에 경쟁이 매우 치열하다는 이야기를 들었습니다. </p><p>직장인들이 많이 다니는 장소나 카페가 적당히 분포된 지역을 찾고 싶습니다. </p><p>또한, 20~30대 젊은 층이 자주 이용하는 핫플레이스 같은 장소도 고려 중입니다. </p><p><br></p><p>혹시 강남구에서 카페 창업을 해보신 분들이 계시다면, 추천할 만한 지역이나 창업 팁이 있으면 조언 부탁드립니다. </p><p>초기 비용은 어느 정도 생각해야 할지, 카페 운영에서 중요한 점들이 무엇인지도 알려주시면 정말 감사하겠습니다!</p>','2024-10-10 16:47:58','2024-10-10 23:59:10','강남구 카페 창업 추천받아요!',13,19,28,11,0),(49,'<h2>편의점 창업, 진입 장벽은 낮지만 성공의 열쇠는 무엇일까?</h2><p><br></p><p>안녕하세요, 창업왕입니다. 많은 분들이 편의점 창업을 쉬운 창업 아이템으로 생각하시지만, 실제로 운영해보면 단순히 진입 장벽이 낮다고 해서 성공하는 것은 아닙니다. </p><p>제가 경험한 편의점 창업에서 가장 중요한 것은 <strong>입지 선정</strong>입니다. 아무리 좋은 프랜차이즈 브랜드라도, 위치가 적절하지 않으면 매출이 오르지 않아요. </p><p>주거지, 학교, 오피스 밀집 지역과 같은 <strong>유동 인구</strong>가 많은 곳을 선택하는 것이 필수적입니다.</p><p><br></p><p><img src=\"[image0]\" width=\"420\" style=\"\"></p><p><br></p><p>또한, <strong>24시간 운영</strong>이 가능한지 여부도 중요한 고려 사항입니다. </p><p>요즘은 인건비 상승으로 인해 일부 편의점이 24시간 운영을 포기하기도 하지만, 늦은 시간대 매출이 높은 지역에서는 여전히 24시간 운영이 필수입니다. </p><p>하지만 <strong>인건비</strong> 부담을 줄이기 위해서는 무인 운영 시스템을 일부 도입하는 것도 고려할 만합니다. 최근에는 무인 계산대 도입으로 인건비를 줄이는 편의점이 많아지고 있습니다.</p><p><br></p><p><strong>상품 구성</strong> 또한 성공을 좌우하는 중요한 요소입니다. 지역 특성에 맞는 상품을 적극적으로 도입하고, 시즌별로 판매되는 한정 상품들을 적절히 배치하는 것이 매출을 끌어올리는 데 효과적입니다. 예를 들어, 학교 주변이라면 학용품이나 간단한 문구류를 추가하고, 직장인 밀집 지역이라면 간단한 도시락이나 건강 간식을 확대하는 방식이 좋습니다.</p><p><br></p><p>마지막으로 <strong>본사와의 관계 관리</strong>도 매우 중요합니다. 본사에서 제공하는 지원은 창업 초기에는 도움이 될 수 있지만, 지나치게 의존하지 말고 매장 운영의 주도권을 가지고 있어야 합니다. </p><p><strong>자율성과 차별화된 서비스</strong>를 통해 지역 내에서 경쟁력을 갖추는 것이 성공의 관건입니다.</p><p><br></p><p>편의점 창업은 소자본 창업 아이템으로 인기가 많지만, 성공적인 운영을 위해서는 철저한 준비와 현장 감각이 필요합니다. </p><p>예비 창업자 여러분이 더 나은 선택을 할 수 있도록 도움이 되었기를 바랍니다!</p><p><img src=\"[image1]\"></p>','2024-10-10 17:00:17','2024-10-11 00:04:47','편의점 창업',18,41,4,11,0),(50,'<h1>안녕하세요! </h1><p><br></p><p>저는 서울에서 <strong style=\"color: rgb(230, 0, 0);\">회 포장 전문점</strong>을 열려고 준비하고 있는 예비 창업자입니다. </p><p>최근에는 배달과 포장이 대세인데, 회는 식당에서만 먹는 경우가 많다 보니 이쪽에 시장 기회가 있을지 궁금합니다. </p><p><br></p><p><img src=\"[image0]\" width=\"357\" style=\"\"><img src=\"[image1]\" width=\"400\" style=\"\"></p><p>신선한 횟감을 고객들이 집에서 간편하게 즐길 수 있도록 포장해주는 전문점을 생각 중인데, 서울에서 이런 사업이 성공할 가능성이 있을까요? </p><p>특히 강남이나 여의도 같은 직장인 밀집 지역을 타겟으로 하려고 합니다. </p><p>점심시간이나 저녁 퇴근 후에 간편하게 포장해서 집에서 먹을 수 있도록 하려는데, 고객층을 어떻게 설정해야 할지도 고민입니다. </p><p><br></p><p>혹시 회 창업 경험이 있으시거나, 아이디어 있으신 분들의 조언 부탁드립니다!</p>','2024-10-10 17:08:41','2024-10-11 00:04:41','회 포장 전문점 창업 준비 중입니다',32,13,36,11,0);
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  9:07:43
