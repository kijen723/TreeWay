-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: tree_way
-- ------------------------------------------------------
-- Server version	8.0.39-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article_attached_file`
--

DROP TABLE IF EXISTS `article_attached_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article_attached_file` (
  `article_attached_file_id` bigint NOT NULL AUTO_INCREMENT,
  `file_name` varchar(3000) NOT NULL,
  `file_path` varchar(3000) NOT NULL,
  `article_id` bigint NOT NULL,
  PRIMARY KEY (`article_attached_file_id`),
  KEY `fk_article_attached_file_article_id` (`article_id`),
  CONSTRAINT `fk_article_attached_file_article_id` FOREIGN KEY (`article_id`) REFERENCES `article` (`article_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article_attached_file`
--

LOCK TABLES `article_attached_file` WRITE;
/*!40000 ALTER TABLE `article_attached_file` DISABLE KEYS */;
INSERT INTO `article_attached_file` VALUES (33,'1728566735112_image0.png','src/main/resources/attacted_file/1728566735112_image0.png',39),(36,'1728566845565_image0.png','src/main/resources/attacted_file/1728566845565_image0.png',42),(37,'1728566922169_image0.png','src/main/resources/attacted_file/1728566922169_image0.png',43),(38,'1728567103423_emptyFile','src/main/resources/attacted_file/1728567103423_emptyFile',44),(39,'1728570380738_emptyFile','src/main/resources/attacted_file/1728570380738_emptyFile',45),(40,'1728570646651_emptyFile','src/main/resources/attacted_file/1728570646651_emptyFile',46),(41,'1728570754448_emptyFile','src/main/resources/attacted_file/1728570754448_emptyFile',47),(42,'1728578878008_image0.png','src/main/resources/attacted_file/1728578878008_image0.png',48),(43,'1728579616620_image0.png','src/main/resources/attacted_file/1728579616620_image0.png',49),(44,'1728579616632_image1.png','src/main/resources/attacted_file/1728579616632_image1.png',49),(45,'1728580121083_image0.png','src/main/resources/attacted_file/1728580121083_image0.png',50),(46,'1728580121091_image1.png','src/main/resources/attacted_file/1728580121091_image1.png',50);
/*!40000 ALTER TABLE `article_attached_file` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-11  9:07:35
